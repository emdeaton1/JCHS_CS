public class Card
{
   public static final String FACES[] = {"0","A","2","3","4",
      "5","6","7","8","9","10","J","Q","K"};
   private String suit_symbols[] = {"♠","♦","♥","♣"};
   private String suit;
   private int face;
   

   //constructors
  public Card()
  {
    suit = " ";
    face = 0;
  }

  public Card(String s, int f)
  {
    suit = s;
    face = f;
  }

   //set methods
  public void setSuit(String s)
  {
    suit = s;
  }

  public void setSuit(int f)
  {
    face = f;
  }

   //get methods 

  public String getSuit()
  {
    return suit;
  }

   public int getValue()
   {
     return face;
   }

    public int getAltValue()
    {
      if (face == 1)
      {
        return 11;
      } else {
        return face;
      }
    }
  
   //equals method
  public boolean equals(Card obj)
  {
    if(this.getValue()==obj.getValue())
      return true;
    return false;
  }


   public String toString()
   {
     String art = "";
     if (FACES[face] == "10"){
       art += "\n -----\n";
       art += "|" + FACES[face] + "   |\n";
       art += "|  " + getSuit() + "  |\n";
       art += "|   " + FACES[face] + "|\n";
       art += " -----\n";
     }
     else{
         art += "\n -----\n";
         art += "|" + FACES[face] + "    |\n";
         art += "|  " + getSuit() + "  |\n";
         art += "|    " + FACES[face] + "|\n";
         art += " -----\n";
      }
     return art;
   }
 }