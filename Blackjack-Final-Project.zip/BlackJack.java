import java.lang.*;
import java.util.*;

public class BlackJack {
  public String ANSI_RESET = "\u001B[0m"; 
  public String ANSI_RED = "\u001B[31m";
  public String ANSI_GREEN = "\u001B[32m";
  public String ANSI_BLUE = "\u001B[34m";
  public String ANSI_PURPLE = "\u001B[35m";
  private Dealer dealer;
  // private Player player;
  private int numPlayers;
  private ArrayList<Player> players;

  public BlackJack() {
    // instantiate all of your instance variables
    dealer = new Dealer(ANSI_PURPLE);
    // player = new Player();
    numPlayers = 1;
    players = new ArrayList<Player>();
  }

  public void playGame() {
    Scanner input = new Scanner(System.in);
    System.out.println(" _      _               _     _               _    ");
    System.out.println("| |    | |             | |   (_)             | |   ");
    System.out.println("| |__  | |  __ _   ___ | | __ _   __ _   ___ | | __");
    System.out.println("| '_ \\ | | / _` | / __|| |/ /| | / _` | / __|| |/ /");
    System.out.println("| |_) || || (_| || (__ |  <  | || (_| || (__ |  < ");
    System.out.println("|_.__/ |_| \\__,_| \\___||_|\\_\\| | \\__,_| \\___||_|\\_\\");
    System.out.println("                            _/ |                ");
    System.out.println("                           |__/        ");
    System.out.print("How many players? :: ");
    numPlayers = input.nextInt();
    for (int i = 0; i < numPlayers; i++) {
      if (i % 2 == 0) {
        players.add(i, new Player(ANSI_BLUE));
      }
      else {
        players.add(i, new Player(ANSI_GREEN));
      }
    }
    String hit = "";
    do {
      // Step 1
      System.out.println(" ");
      System.out.println("---Shuffling the Deck--- ");
      // Shuffle the deck
      dealer.shuffle();
      // Step 2
      System.out.println(" ");
      System.out.println("---Dealing Cards to All Players--- ");
      // Loop through all the players, deal two cards
      for (int i = 0; i < players.size(); i++) {
        players.get(i).addCardToHand(dealer.deal());
        players.get(i).addCardToHand(dealer.deal());
      }
      // Step 3
      System.out.println(" ");
      System.out.println("---Asking Players to Hit--- ");
      // Loop through all the players
      for (int i = 0; i < players.size(); i++) {
        System.out.println(" ");
        System.out.println(ANSI_RESET + "Player number " + (i + 1) + " ");
        // Print out the players card value
        players.get(i).printPlayerHand();
        // while loop
        do {
          // if card value < 21
          if (players.get(i).getHandValue() < 21) {
            // Ask the player if they want to hit and value is less 21
            System.out.print(ANSI_RESET + "Do you want to hit? (Y or N) :: ");
            hit = input.next();
            // if player wants to hit
            if (hit.equals("Y") || hit.equals("y")) {
              // give the player a card
              players.get(i).addCardToHand(dealer.deal());
              // Print out the players cards
              players.get(i).printPlayerHand();
            } else {
              // break out of the loop
              break;
            }
          } else if (players.get(i).getHandValue() == 21) {
            System.out.println("Blackjack");
            break;
          } else {
            // player is over 21
            System.out.println("Player Busted!!!!!");
            break;
          }
          // end if
          // end while
        } while (true);
      }
      // Handle the dealer getting more cards here
      System.out.println(" ");
      System.out.println("---Dealer Auto Deal--- ");
      System.out.println(" ");
      System.out.println(ANSI_RESET + "Dealer ");
      // Print out the dealer's cards
      dealer.printPlayerHand();
      // while loop
      do {
        // if card value < 21
        if (dealer.getHandValue() < 17) {
          System.out.println("Dealer hand is less than 17");
          System.out.println("Dealer needs another card");
          // Dealer must deal another card to themself
          hit = "Y";
          // if player wants to hit
          if (hit.equals("Y") || hit.equals("y")) {
            // give the dealer a card
            dealer.addCardToHand(dealer.deal());
            // Print out the dealer cards
            dealer.printPlayerHand();
          } else {
            // break out of the loop
            break;
          }
        } else if (dealer.getHandValue() > 21) {
          // Dealer is over 21
          System.out.println("Dealer Busted!!");
          break;
        } else {
          // If Dealer hand >= 17 they cannot draw any more cards
          System.out.println("Dealer hand is equal to or greater than 17");
          break;
        }
        // end if
        // end while
      } while (true);
      // Step 4
      System.out.println(" ");
      System.out.println("---Printing All Player Hands--- ");
      // Loop through all the players
      for (int i = 0; i < players.size(); i++) {
        // Print out the players card value
        System.out.println(" ");
        System.out.println(ANSI_RESET + "Player number " + (i + 1) + " ");
        players.get(i).printPlayerHand();
      }
      // Print out the Dealer's cards
      System.out.println(" ");
      System.out.println(ANSI_RESET + "Dealer ");
      dealer.printPlayerHand();
      // Step 5
      System.out.println(" ");
      System.out.println(ANSI_RESET + "---Who Won--- ");
      // determine who won
      this.whoWon();

      for (int i = 0; i < players.size(); i++) {
        System.out.println("");
        if (i % 2 == 0) {
          System.out.println(ANSI_BLUE + "Player " + (i + 1) + " won " + players.get(i).getWinCount() + " hand(s)");
        }
        else {
          System.out.println(ANSI_GREEN + "Player " + (i + 1) + " won " + players.get(i).getWinCount() + " hand(s)");
        }
        
      }
      System.out.println("");
      System.out.println(ANSI_PURPLE + "Dealer won " + dealer.getWinCount() + " hand(s).");

      // Step 6
      System.out.println(" ");
      System.out.println(ANSI_RESET + "---Play Again--- ");
      // ***Update win total for winning player

      // another game is to be played
      System.out.println(" ");
      System.out.print("Do you want to play again? (Y or N) :: ");
      hit = input.next();

      // clear out previous players
      if (hit.equals("Y") || hit.equals("y")) {
        // Loop through all the players, deal two cards
        for (int i = 0; i < players.size(); i++) {
          players.get(i).resetHand();
          players.get(i).resetHand();
        }
        dealer.resetHand();
        clear();
      }
    } while (hit.equals("Y") || hit.equals("y"));

    /*
     * for (int i = 0; i<players.size(); i++) {
     * int playerIn = i+1;
     * System.out.println("Player "+ playerIn + " won " +
     * players.get(i).getWinCount() + " hand(s)");
     * }
     * System.out.println("Dealer won " + dealer.getWinCount() + " hands.");
     */

    input.close();
  }

  public void whoWon() {
    int playerTotal = 0;
    int dealerTotal = dealer.getHandValue();
    boolean dealerWon = false;

    for (int index = 0; index < players.size(); index++) {
      if ( players.get(index).getAltHandValue() > 21 ) {
        playerTotal = players.get(index).getHandValue();
      } else {
        playerTotal = players.get(index).getAltHandValue();
      }
      
      
      if (playerTotal == dealerTotal) {
        System.out.println("\nPlayer " + (index + 1) + " and Dealer Tie - Push");
        dealerWon = false;
      } else if (playerTotal > 21 && dealerTotal <= 21) {
        System.out.println("\nDealer wins - Player " + (index + 1) + " busted!");
        if (dealerWon == false && index == 0 )
        {
          dealerWon = true;
        }
      } else if (playerTotal <= 21 && dealerTotal > 21) {
        System.out.println("\nPlayer " + (index + 1) + " wins - Dealer busted!");
        players.get(index).setWinCount();
        dealerWon = false;
      } else if (playerTotal > 21 && dealerTotal > 21) {
        System.out.println("Both Player " + (index + 1) + " and Dealer busted!");
        dealerWon = false;
      } else if (playerTotal < dealerTotal) {
        System.out.println("\nDealer has bigger hand value than Player " + (index + 1) + "!");
        if (dealerWon == false && index == 0 )
        {
          dealerWon = true;
        }
      } else {
        System.out.println("\nPlayer " + (index + 1) + " has bigger hand value!");
        players.get(index).setWinCount();
        dealerWon = false;
      }
    }
    if ( dealerWon == true ) {
      dealer.setWinCount();
    }
  }

  public static void clear() {
    System.out.print("\033[H\033[2J");
    System.out.flush();
  }
}
