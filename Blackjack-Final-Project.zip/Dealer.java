public class Dealer extends Player
{  
	//define a deck of cards
  Deck deck = new Deck();	
  String color = "";

	public Dealer(String c) {
    super(c);
	}

	public void  shuffle()
	{
    deck.shuffle();
	}

	public Card  deal(){
    return deck.nextCard();
	}
	
	public int numCardsLeftInDeck()
	{
		 return deck.numCardsLeft();
	}

	public boolean hit()
	{
	   return super.hit();
  }
}
