public class BlackJackCard extends Card
{

   //constructors
  public BlackJackCard()
  {
    super();
  }
  
  public BlackJackCard(String s, int f)
  {
    super(s, f);
  }
 
   public int getValue()
   {  
     return super.getValue();
   }
}