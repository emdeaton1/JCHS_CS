import java.util.*;

class Main {
  public static void main(String[] args) {
    /******************************
     * BLACK JACK PART 1
    *******************************/
    /*
		Card one = new BlackJackCard();
		System.out.println(one);

		Card two = new BlackJackCard(1, "DIAMONDS");
		System.out.println(two);

		Card three = new BlackJackCard(4, "CLUBS");
		System.out.println(three);
		
		Card four = new BlackJackCard(12, "SPADES");
		Systemout.println(four);
	
		Card five = new BlackJackCard(12, "HEARTS");
		System.out.println(five);	
		
		Card six = new BlackJackCard(9, "SPADES");
		System.out.println(six);				

    System.out.println();
		System.out.println(one.equals(two));
    //BELOW NEEDS TO RETURN TRUE
		System.out.println(one.equals(one));		
		System.out.println(four.equals(five));	
		System.out.println(three.equals(four));						

    System.out.println();
    */
    /*
    /******************************
     * BLACK JACK PART 2
    *******************************/
    /*
    Deck deck = new Deck();	

    //TESTING
    //deck.CheckCards();

    //TESTING
    //System.out.println(deck.nextCard(52));
    //System.out.println(deck.nextCard(42));
    //System.out.println(deck.nextCard(32));
    //System.out.println(deck.nextCard(25));
    //System.out.println(deck.nextCard(22));
    //System.out.println(deck.nextCard(5));
    //System.out.println(deck.nextCard(12));
    //System.out.println(deck.nextCard(2));
    
		for( int i = 0; i < Deck.NUMCARDS; i++ ) 
    {
		  System.out.println(deck.nextCard());
		  //System.out.println(i + " - " + deck.nextCard());
      //deck.decrementTopCard();
		}
		
		System.out.println("\n");
		
		System.out.println("num cards left in the deck == " + deck.numCardsLeft());
		
		System.out.println("\nshuffling");
		
    deck.shuffle();

		System.out.println("num cards left in the deck == " + deck.numCardsLeft());

    System.out.println("\n\ntoString");
    System.out.println(deck);

    */

    /******************************
     * BLACK JACK PART 3
    *******************************/
    /*
  	Player player = new Player();	
		Deck playerDeck = new Deck();
		playerDeck.shuffle();
		
		player.addCardToHand(playerDeck.nextCard());
		player.addCardToHand(playerDeck.nextCard());

		System.out.println("\ntoString");
		System.out.println(player);	
		
		System.out.println("\nhandValue");
		System.out.println(player.getHandValue());					
		
		player.addCardToHand(playerDeck.nextCard());
		player.addCardToHand(playerDeck.nextCard());

		System.out.println("\ntoString");
		System.out.println(player);	
		
		System.out.println("\nhandValue");
		System.out.println(player.getHandValue());									
    */
 
    /******************************
     * BLACK JACK PART 4
    *******************************/
		//Code to test the Dealer
		/*Dealer dealer = new Dealer();
		Player player = new Player();
		
		dealer.shuffle();
		
		player.addCardToHand(dealer.deal());
		dealer.addCardToHand(dealer.deal());
		player.addCardToHand(dealer.deal());
		dealer.addCardToHand(dealer.deal());
		
		int playerTotal = player.getHandValue();
		int dealerTotal = dealer.getHandValue();
		
		System.out.println("\nPLAYER ");
		System.out.println("Hand Value :: " + playerTotal );
		System.out.println("Hand Size :: " + player.getHandSize() );
		System.out.println("Cards in Hand :: " + player.toString() );
    
		System.out.println("\nDEALER ");
		System.out.println("Hand Value :: " + dealerTotal );
		System.out.println("Hand Size :: " + dealer.getHandSize() );
		System.out.println("Cards in Hand :: " + dealer.toString() );
		
		if(playerTotal > 21 && dealerTotal <= 21)
		{
		  System.out.println("\nDealer wins - Player busted!");
		}
		else if(playerTotal  <= 21 && dealerTotal > 21)
		{
		  System.out.println("\nPlayer wins - Dealer busted!");
		}
		else if(playerTotal > 21 && dealerTotal > 21)
    {
		  System.out.println("Both players bust!");
		}
		else if(playerTotal < dealerTotal)
    {
		  System.out.println("\nDealer has bigger hand value!");
		}
		else
    {
		  System.out.println("\nPlayer has bigger hand value!");
		}			*/		
 
     /******************************
     * BLACK JACK PART 5
    *******************************/   
    BlackJack game = new BlackJack();
		game.playGame();
  }
}