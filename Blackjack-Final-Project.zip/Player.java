import java.util.*;

public class Player {
  private ArrayList<Card> hand;
  private int winCount;
  private int playerScore;
  private int handValue;
  private int altHandValue;
  public String ANSI_RESET = "\u001B[0m";
  public String ANSI_RED = "\u001B[31m";
  public String ANSI_BLUE = "\u001B[34m";
  public String ANSI_WHITE = "\u001B[37m";
  private String color = "";

  public Player(String c) {
    hand = new ArrayList<Card>();
    winCount = 0;
    playerScore = 0;
    handValue = 0;
    altHandValue = 0;
    color = c;
  }

  public Player(int score) {
    playerScore = score;
  }

  public void addCardToHand(Card temp) {
    hand.add(temp);
    handValue += temp.getValue();
    altHandValue += temp.getAltValue();
  }

  public void resetHand() {
    hand.clear();
    handValue = 0;
    altHandValue = 0;
  }

  public void setWinCount() {
    winCount++;
  }

  public int getWinCount() {
    return winCount;
  }

  public int getHandSize() {
    return hand.size();
  }

  public int getHandValue() {
    return handValue;
  }

  public int getAltHandValue() {
    return altHandValue;
  }

  public boolean hit() {
    return false;
  }

  public String printHand() {
    String cards = "";

    for (Card c : hand) {
      cards += c + " ";
    }

    return cards;
  }

  public void printPlayerHand() {
    if (this.getHandValue() != this.getAltHandValue()) {
      if (this.getAltHandValue() > 21) {
        System.out.println(ANSI_RED + "Hand Value :: " + this.getHandValue());
      } else {
        System.out.println(ANSI_RED + "Alternate Hand Value :: " + this.getAltHandValue());
      }
    } else {
      System.out.println(ANSI_RED + "Hand Value :: " + this.getHandValue());
    }
    System.out.println(color + "Cards in Hand :: " + this.printHand());
  }

}