import java.util.*;

public class Deck {
  public static final int NUMFACES = 13;
  public static final int NUMSUITS = 4;
  public static final int NUMCARDS = 52;

  public static final String SUITS[] = { "♣", "♠", "♦", "♥" };

  private int topCardIndex;
  private ArrayList<Card> stackOfCards;

  // constructor
  public Deck() {
    Scanner input = new Scanner(System.in);
    int aceNum = 0;
    // initialize the instance variables
    topCardIndex = NUMCARDS - 1;
    stackOfCards = new ArrayList<Card>();

    for (int s = 0; s < NUMSUITS; s++) {
      for (int f = 1; f <= NUMFACES; f++) {
        /*if (s==1)
        {
          if (s + 10 <= 21)
          {
            System.out.println("Ace = 11");
            stackOfCards.add(new BlackJackCard(SUITS[11], f));
          }
          System.out.println("Ace = 1");
          stackOfCards.add(new BlackJackCard(SUITS[1], f));
        }*/
        if (f>10)
        {
          stackOfCards.add(new BlackJackCard(SUITS[s], 10));
        } else {
          stackOfCards.add(new BlackJackCard(SUITS[s], f));
        }
      }
    }
    // one loop to go through all SUITS
    // one loop to go through all FACES
    // add in each new Card() to the Deck
  }

  public int size() {
    return stackOfCards.size();
  }

  public int numCardsLeft() {
    if (topCardIndex < 0)
      topCardIndex = 0;
    return topCardIndex;
  }

  public void shuffle() {
    this.resetTopCard();
    Collections.shuffle(stackOfCards);
  }

  public void resetTopCard() {
    topCardIndex = NUMCARDS - 1;
  }

  public void CheckCards() {
    for (Card c : stackOfCards) {
      System.out.println(c);
    }
  }

  public Card nextCard(int i) {
    Card c = stackOfCards.get(i);
    return c;
  }

  public Card nextCard() {
    return stackOfCards.get(topCardIndex--);
  }

  public String toString() {
    String result = "";

    for (Card c : stackOfCards) {
      result += c + " ";
    }

    return result + "\n topCardIndex = " + topCardIndex;
  }
}
