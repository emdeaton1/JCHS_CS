import java.util.Scanner;
import java.lang.Math;

public class cone
  {
    public static void printCone()
    {
      Scanner input2 = new Scanner(System.in);
      int num = 0;
      double radius, height;

      System.out.println("");
      System.out.println("--Calculating the Volume of a Cone--");
      System.out.println("");

      while(true)
      {
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input2.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          System.out.print("Enter a radius: ");
          radius = input2.nextDouble();
          System.out.print("Enter a height: ");
          height = input2.nextDouble();
          System.out.println("");
          double volume = ((Math.PI*Math.pow(radius, 2))*height)/3;
          System.out.println("Volume: " + volume);
          System.out.println("");
        }
      }

    }
  }