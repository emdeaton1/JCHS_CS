import java.util.Scanner;
import java.lang.Math;

public class cube
  {
    public static void printCube()
    {
      Scanner input2 = new Scanner(System.in);
      int num = 0;
      double side;

      System.out.println("");
      System.out.println("--Calculating the Area of a Cube--");
      System.out.println("");

      while(true)
      {
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input2.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          System.out.print("Enter a side: ");
          side = input2.nextDouble();
          System.out.println("");
          double area = (6*Math.pow(side, 2));
          System.out.println("Area: " + area);
          System.out.println("");
        }
      }

    }
  }