import java.util.Scanner;
import java.lang.Math;

public class circle
  {
    public static void printCircle()
    {
      Scanner input2 = new Scanner(System.in);
      int num = 0;
      double radius;

      System.out.println("");
      System.out.println("--Calculating the Area of a Circle--");
      System.out.println("");

      while(true)
      {
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input2.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          System.out.print("Enter a radius: ");
          radius = input2.nextDouble();
          System.out.println("");
          double area = Math.PI*Math.pow(radius, 2);
          System.out.println("Area: " + area);
          System.out.println("");
        }
      }

    }
  }