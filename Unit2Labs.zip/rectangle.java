import java.util.Scanner;

public class rectangle
  {
    public static void printRectangle()
    {
      Scanner input = new Scanner(System.in);
      int num = 0;
      double length, width;

      System.out.println("");
      System.out.println("--Calculating the Area of a Rectangle--");
      System.out.println("");
      
      while(true)
      {
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          System.out.print("Enter a length: ");
          length = input.nextDouble();
          System.out.print("Enter a width : ");
          width = input.nextDouble();
          System.out.println("");
          double area = (2*length) + (2*width);
          System.out.println("Area: " + area);
          System.out.println("");
        }
      }

    }
  }