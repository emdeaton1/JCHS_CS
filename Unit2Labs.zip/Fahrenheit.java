import java.util.Scanner;
import java.lang.Math;

public class Fahrenheit
  {
    public static void printCelsius()
    {
      Scanner input2 = new Scanner(System.in);
      int num = 0;
      double degrees;

      System.out.println("");
      System.out.println("--Converting Degrees to Celsius--");
      System.out.println("");

      while(true)
      {
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input2.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          System.out.print("Enter a temperature (Fahrenheit): ");
          degrees = input2.nextDouble();
          System.out.println("");
          double celsius = (degrees-32)*5/9;
          System.out.println("Celsius: " + celsius + " degrees Celsius");
          System.out.println("");
        }
      }

    }
  }