import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    rectangle answer = new rectangle();
    answer.printRectangle();

    trapezoid answer2 = new trapezoid();
    answer2.printTrapezoid();

    cone answer3 = new cone();
    answer3.printCone();

    cube answer4 = new cube();
    answer4.printCube();

    circle answer5 = new circle();
    answer5.printCircle();

    Fahrenheit answer6 = new Fahrenheit();
    answer6.printCelsius();

  }
}