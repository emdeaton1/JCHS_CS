import java.util.*;

public class switchFirst
  {
    public static void printSwitchFirst()
    {
      String s1, s2;
  
      Scanner input4 = new Scanner(System.in);
  
      System.out.print("Enter a 2 strings: ");
      s1 = input4.next();
      s2 = input4.next();
      
      System.out.print(s2.charAt(0));
      
      System.out.println(s1.substring(1));
    }
  }