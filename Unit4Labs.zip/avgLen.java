import java.util.*;

public class avgLen
  {
    private String one="", two="";
    
    public static void printAvgLen()
    {
      String s1, s2;
  
      Scanner input1 = new Scanner(System.in);
  
      System.out.print("Enter a 2 strings: ");
      s1 = input1.next();
      s2 = input1.next();
  
      avgLen mean = new avgLen();
      System.out.println(mean.getAverage(s1, s2));
    }
    
    public double getAverage(String s3, String s4)
      {
        double average = ((double)s3.length() + (double)s4.length())/2;
        return average;
      }
  }