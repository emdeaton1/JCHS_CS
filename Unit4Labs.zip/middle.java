import java.util.*;

public class middle
  {
    public static void printMiddle()
    {
      String s1;
  
      Scanner input3 = new Scanner(System.in);
  
      System.out.print("Enter a string: ");
      s1 = input3.next();
      
      int i = s1.length();
      System.out.println(s1.charAt(i/2));
    }
  }