import java.util.*;

public class firstLastVowel
  {
    public static void printFirstLastVowel()
    {
      String s1;
  
      Scanner input7 = new Scanner(System.in);
  
      System.out.print("Enter a string: ");
      s1 = input7.next();
      
      int i = s1.length();
      
      if(s1.charAt(0) == 'a'|| s1.charAt(0) == 'e'|| s1.charAt(0) == 'i' || s1.charAt(0) == 'o' || s1.charAt(0) == 'u' || s1.charAt(0) == 'A'|| s1.charAt(0) == 'E'|| s1.charAt(0) == 'I' || s1.charAt(0) == 'O' || s1.charAt(0) == 'U' && s1.charAt(i-1) == 'a'|| s1.charAt(i-1) == 'e'|| s1.charAt(i-1) == 'i' || s1.charAt(i-1) == 'o' || s1.charAt(i-1) == 'u' || s1.charAt(i-1) == 'A'|| s1.charAt(i-1) == 'E'|| s1.charAt(i-1) == 'I' || s1.charAt(i-1) == 'O' || s1.charAt(i-1) == 'U')
      {
        System.out.println("yes");
      }
      else
      {
        System.out.println("no");
      }
    }
  }