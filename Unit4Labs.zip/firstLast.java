import java.util.*;

public class firstLast
  {
    public static void printFirstLast()
    {
      String s1, s2;
  
      Scanner input2 = new Scanner(System.in);
  
      System.out.print("Enter a 2 strings: ");
      s1 = input2.next();
      s2 = input2.next();
      
      int i = s2.length();
      
      System.out.print(s1.charAt(0));
      
      System.out.println(s2.charAt(i-1));
    }
  }