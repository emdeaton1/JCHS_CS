import java.util.*;

class Main {
  public static void main(String[] args) {
    
    Scanner input = new Scanner(System.in);
    int num = 0;
    
    while(true)
      {
        System.out.println("");
        System.out.println("--Calculating the Average of Two String Lengths--");
        System.out.println("");
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          avgLen answer1 = new avgLen();
          answer1.printAvgLen();
        }
      }

    while(true)
      {
        System.out.println("");
        System.out.println("--Printing the First and Last Char--");
        System.out.println("");
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          firstLast answer2 = new firstLast();
          answer2.printFirstLast();
        }
      }
        
    while(true)
      {
        System.out.println("");
        System.out.println("--Printing the Middle Char--");
        System.out.println("");
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          middle answer3 = new middle();
          answer3.printMiddle();
        }
      }
    
      while(true)
      {
        System.out.println("");
        System.out.println("--Switching the First Letter--");
        System.out.println("");
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          switchFirst answer4 = new switchFirst();
          answer4.printSwitchFirst();
        }
      }

    while(true)
      {
        System.out.println("");
        System.out.println("--Adding SSN Parts--");
        System.out.println("");
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          social answer5 = new social();
          answer5.printSSN();
        }
      }
        
    while(true)
      {
        System.out.println("");
        System.out.println("--If Statements--");
        System.out.println("");
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          addSubMult answer6 = new addSubMult();
          System.out.printf("%.2f\n",answer6.subMult());
        }
      }

    while(true)
      {
        System.out.println("");
        System.out.println("--First and Last Chars Vowels--");
        System.out.println("");
        System.out.print("Enter 1 to continue and 0 to quit: ");
        num = input.nextInt();
        System.out.println("");
        
        if (num == 0){
          break;
        }
        else{
          firstLastVowel answer7 = new firstLastVowel();
          answer7.printFirstLastVowel();
        }
      }
  }
}