import java.util.*;

public class social
  {
    public static void printSSN()
    {
      String s1, s2;
      int total, dash, dash2;
  
      Scanner input5 = new Scanner(System.in);
  
      System.out.print("Enter a social security number: ");
      s1 = input5.next();

      int l = s1.length();

      dash = s1.indexOf('-');
      s2 = s1.substring(0, dash);
      total = Integer.parseInt(s2);

      
      dash2 = s1.lastIndexOf('-');
      s2 = s1.substring(dash2+1,l);
      total += Integer.parseInt(s2);

      s2 = s1.substring(dash+1, dash2);
      total += Integer.parseInt(s2);
      
      System.out.println("SS# " + s1 + " has a total of " + total);
    }
  }