import java.util.*;

public class addSubMult
  {
    public static double subMult()
    {
      double a, b;
  
      Scanner input6 = new Scanner(System.in);
  
      System.out.print("Enter 2 numbers: ");
      a = input6.nextDouble();
      b = input6.nextDouble();
      
      if (a > b)
        {
          return a - b;
        }
      else if (a < b)
      {
        return b - a;
      }
      else 
      {
        return a * b;
      }
    }
  }