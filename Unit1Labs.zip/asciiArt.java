public class asciiArt
  {
    public static void printArt()
    {
      System.out.println("");
      System.out.println("Question: 3");
      System.out.println("");
      System.out.println("                            _");
      System.out.println("                          .'' `'.__");
      System.out.println("                         /      \\ `\'\"-,");
      System.out.println("        .-\'\'\'\'--...__..-/ .     |      \\");
      System.out.println("      .\'               ; :\'     \'.  a   |");
      System.out.println("     /                 | :.       \\     =\\");
      System.out.println("    ;                   \\':.      /  ,-.__;.-;`");
      System.out.println("   /|     .              \'--._   /-.7`._..-;`");
      System.out.println("  ; |       '                |`-'      \\  =|");
      System.out.println("  |/\\        .   -' /     /  ;         |  =/");
      System.out.println("  (( ;.       ,_  .:|     | /     /\\   | =|");
      System.out.println("   ) / `\\     | `\"\"`;     / |    | /   / =/");
      System.out.println("     | ::|    |      \\    \\ \\    \\ `--' =/");
      System.out.println("    /  '/\\    /       )    |/     `-...-`");
      System.out.println("   /    | |  `\\    /-'    /;");
      System.out.println("   \\  ,,/ |    \\   D    .'  \\");
      System.out.println("    `\"\"`   \\  nnh  D_.-'L__nnh");
      System.out.println("            `\"\"\"`");
      System.out.println("");
      System.out.println(" _                                                      _");
      System.out.println("::``--..__                                     ___..--''::");
      System.out.println("|::::::::::`-.._                          _,-':::::::::::|");
      System.out.println("|:::((o)):,--.:::.                      ,::::--::((o)):::|");
      System.out.println("::|___(::'--';--::`.     \\      /     ,'-':::`--'::)___|:;");
      System.out.println(" :_|::::::;'_     `-`.   :     :    ,'       ,`:::::::|_:");
      System.out.println(" |:::)__)(   `-._     `. :     |  ,'      ,-'   ):)__)::|");
      System.out.println(" |::/__/::\\`-..__;-._   \\ \\    ; /     ,-'--.._/:/__/:::;");
      System.out.println(" ::'--'::::\\  ____   `.  \\ \\,./ /   ,-'     ,-::'--':::/");
      System.out.println("  \\:::::::::`'.   ``-._`. \\()()/ ,-'--..__,:::::::_::;'");
      System.out.println("   `>''''---...`------,:.`.>'`<,'_____.'... --'''     `.");
      System.out.println("  ,'     __:._ _..--''   ,`:  ;`.     ``--._````---..._::");
      System.out.println(" /: --:''    _/        ,','|`'|`.`.         |``--..__ .:|");
      System.out.println("(::.  :. _,-' \\      ,' / /|--|\\ `.`.       ;._  .:  `:::");
      System.out.println(" \\:: _:'::.  ,'`---,' ,' / |--| \\  ` `. __,'.  `-:'    :/");
      System.out.println("  \\;'    ':;' '. ,' ,'  /  :--;  \\  `. `. .:.`.   `.-._/");
      System.out.println("   \\'.   ,;-.  ,'  /':./    \\/    \\.:'\\  `.  ,-:..:'  /");
      System.out.println("    `:.,'((O))/   /   /            \\   \\ .'\\((O))`: ,'");
      System.out.println("      `-._`-'/':./ _,'              `-._\\   \\`-'_,-'");
      System.out.println("          `-:___:-'                     `-.__;-'");
    }
  }