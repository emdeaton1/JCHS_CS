import java.util.Scanner;

public class input
  {
    public static void printInput()
    {
      System.out.println("");
      System.out.println("Question: 5");
      System.out.println("");
      Scanner keyboard = new Scanner(System.in);
      int intOne, intTwo;
      double doubleOne, doubleTwo;
      float floatOne, floatTwo;
      
      System.out.print("Enter an integer :: ");
      intOne = keyboard.nextInt();
      System.out.print("Enter an integer :: ");
      intTwo = keyboard.nextInt();
      System.out.println("");
      
      System.out.print("Enter an double :: ");
      doubleOne = keyboard.nextDouble();
      System.out.print("Enter an double :: ");
      doubleTwo = keyboard.nextDouble();
      System.out.println("");

      System.out.print("Enter an float :: ");
      floatOne = keyboard.nextFloat();
      System.out.print("Enter an float :: ");
      floatTwo = keyboard.nextFloat();
      System.out.println("");
      
      System.out.println("integer one = " + intOne);
      System.out.println("integer two = " + intTwo);
      System.out.println("");
      
      System.out.println("double one = " + doubleOne);
      System.out.println("double two = " + doubleTwo);
      System.out.println("");

      System.out.println("float one = " + floatOne);
      System.out.println("float two = " + floatTwo);
      System.out.println("");
    }
  }