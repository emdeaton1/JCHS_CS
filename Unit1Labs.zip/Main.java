import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    asciiBox answer = new asciiBox();
    answer.printBox();
  
    asciiBox2 answer2 = new asciiBox2();
    answer2.printBox2();
  
    asciiArt answer3 = new asciiArt();
    answer3.printArt();
  
    variables answer4 = new variables();
    answer4.printVariables();
    
    input answer5 = new input();
    answer5.printInput();
  }
}