public class asciiBox
  {
    public static void printBox()
    {
      System.out.println("");
      System.out.println("Question: 1");
      System.out.println("");
      for(int a=0; a<3; a++)
        {
          for(int b=0; b<25; b++)
          {  
            System.out.print("+");
            
            if (b==24)
            {
              System.out.println();
            }
          }
        }
        for(int a=0; a<2; a++)
        {
          for(int b=0; b<25; b++)
          {  
            System.out.print("A");
            
            if (b==24)
            {
              System.out.println();
            }
          }
        }
        for(int a=0; a<3; a++)
        {
          for(int b=0; b<25; b++)
          {  
            System.out.print("+");
            
            if (b==24)
            {
              System.out.println();
            }
          }
        }
        for(int a=0; a<2; a++)
        {
          for(int b=0; b<25; b++)
          {  
            System.out.print("A");
            
            if (b==24)
            {
              System.out.println();
            }
          }
        }
        for(int a=0; a<3; a++)
        {
          for(int b=0; b<25; b++)
          {  
            System.out.print("+");
            
            if (b==24)
            {
              System.out.println();
            }
          }
        }
        for(int a=0; a<2; a++)
        {
          for(int b=0; b<25; b++)
          {  
            System.out.print("A");
            
            if (b==24)
            {
              System.out.println();
            }
          }
        }
        for(int a=0; a<3; a++)
        {
          for(int b=0; b<25; b++)
          {  
            System.out.print("+");
            
            if (b==24)
            {
              System.out.println();
            }
          }
        }
    }
  }