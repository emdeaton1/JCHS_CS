public class asciiBox2
  {
    public static void printBox2()
    {
      System.out.println("");
      System.out.println("Question: 2");
      System.out.println("");
      System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAA");
      System.out.println("+++++++++++++++++++++++++++");
      for(int a=0; a<4; a++)
      {
        for(int b=0; b<1; b++)
        {  
          System.out.println("+++                     +++");
          
          if (b==1)
          {
            System.out.println();
          }
        }
      }
      System.out.println("+++     A+ Comp Sci     +++");
      for(int a=0; a<4; a++)
      {
        for(int b=0; b<1; b++)
        {  
          System.out.println("+++                     +++");
          
          if (b==1)
          {
            System.out.println();
          }
        }
      }
      System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAA");
      System.out.println("+++++++++++++++++++++++++++");
    }
  }